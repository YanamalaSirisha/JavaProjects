package com.ecommerce.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AssertionsTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
