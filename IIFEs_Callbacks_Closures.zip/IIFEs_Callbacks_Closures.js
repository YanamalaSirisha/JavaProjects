//IIFE and Closure
const empId = (function() {
    let count = 0;
    return function() {
      ++count;
      return `emp${count}`;
    };
  })();
  
  console.log("New Emplyee IDs are listed here");
  console.log("Diya: "+empId()); 
  console.log("Brighty: "+empId()); 
  console.log("Hari: "+empId());
   

  //Callbacks
  console.log("\n"); //to start the output from the neext line
  function fullName(firstName, lastName, callback){
    console.log("My name is " + firstName + " " + lastName);
    callback(lastName);
  }
  
  var greeting = function(ln){
    console.log('Welcome ' + ln);
  };
  
  fullName("Diya", "Abc", greeting);
  console.log("\n");
  fullName("Lucky", "Pqr", greeting);
  console.log("\n");
  fullName("Yash", "Xyz", greeting);
  

